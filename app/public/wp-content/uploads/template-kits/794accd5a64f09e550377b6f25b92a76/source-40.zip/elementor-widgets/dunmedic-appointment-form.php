<?php
/**
 * Dunmedic Appointment Form Widget for Elementor
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Dunmedic_Appointment_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dunmedic_appointment_form';
    }

    public function get_title() {
        return esc_html__('Dunmedic Appointment Form', 'dunmedic');
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['dunmedic'];
    }

    public function get_keywords() {
        return ['dunmedic', 'appointment', 'form', 'booking', 'medical'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'form_title',
            [
                'label' => esc_html__('Form Title', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Book Appointment', 'dunmedic'),
                'placeholder' => esc_html__('Enter form title', 'dunmedic'),
            ]
        );

        $this->add_control(
            'form_description',
            [
                'label' => esc_html__('Form Description', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Schedule your appointment with our medical professionals', 'dunmedic'),
                'placeholder' => esc_html__('Enter form description', 'dunmedic'),
            ]
        );

        $this->add_control(
            'enable_specialty_field',
            [
                'label' => esc_html__('Enable Specialty Selection', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'dunmedic'),
                'label_off' => esc_html__('No', 'dunmedic'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'enable_doctor_field',
            [
                'label' => esc_html__('Enable Doctor Selection', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'dunmedic'),
                'label_off' => esc_html__('No', 'dunmedic'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'form_background',
            [
                'label' => esc_html__('Form Background', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .appointment-form-container' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'form_border_radius',
            [
                'label' => esc_html__('Border Radius', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'selectors' => [
                    '{{WRAPPER}} .appointment-form-container' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $enable_specialty = $settings['enable_specialty_field'] === 'yes';
        $enable_doctor = $settings['enable_doctor_field'] === 'yes';
        
        ?>
        <div class="dunmedic-appointment-form-widget">
            <div class="appointment-form-container">
                <h3 class="appointment-form-title"><?php echo esc_html($settings['form_title']); ?></h3>
                <?php if (!empty($settings['form_description'])): ?>
                    <p class="form-description"><?php echo esc_html($settings['form_description']); ?></p>
                <?php endif; ?>
                
                <form class="dunmedic-appointment-form" id="appointmentForm">
                    <div class="form-row">
                        <?php if ($enable_specialty): ?>
                        <div class="form-field">
                            <label for="specialty">Medical Specialty</label>
                            <select id="specialty" name="specialty" required>
                                <option value="">Select Specialty</option>
                                <option value="critical-care">Critical Care</option>
                                <option value="internal-medicine">Internal Medicine</option>
                                <option value="dental">Dental</option>
                                <option value="emergency">Emergency</option>
                                <option value="dermatology">Dermatology</option>
                                <option value="family-medicine">Family Medicine</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($enable_doctor): ?>
                        <div class="form-field">
                            <label for="doctor">Select Doctor</label>
                            <select id="doctor" name="doctor" required>
                                <option value="">Select Doctor</option>
                                <option value="dr-morgan-smith">Dr. Morgan Smith</option>
                                <option value="dr-roy-coleman">Dr. Roy Coleman</option>
                                <option value="dr-lyla-miss">Dr. Lyla Miss</option>
                                <option value="dr-lake-yinus">Dr. Lake Yinus</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        
                        <div class="form-field">
                            <label for="appointment-date">Appointment Date</label>
                            <input type="date" id="appointment-date" name="appointment_date" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-field">
                            <label for="patient-name">Full Name</label>
                            <input type="text" id="patient-name" name="patient_name" required>
                        </div>
                        
                        <div class="form-field">
                            <label for="patient-phone">Phone Number</label>
                            <input type="tel" id="patient-phone" name="patient_phone" required>
                        </div>
                        
                        <div class="form-field">
                            <label for="patient-email">Email Address</label>
                            <input type="email" id="patient-email" name="patient_email" required>
                        </div>
                        
                        <div class="form-field">
                            <label for="appointment-time">Preferred Time</label>
                            <input type="time" id="appointment-time" name="appointment_time" required>
                        </div>
                    </div>
                    
                    <div class="form-field">
                        <label for="message">Additional Message</label>
                        <textarea id="message" name="message" rows="4" placeholder="Please describe your symptoms or reason for visit..."></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-calendar-check"></i>
                        Make Appointment
                    </button>
                </form>
            </div>
        </div>

        <style>
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .form-description {
            text-align: center;
            margin-bottom: 2rem;
            opacity: 0.9;
        }
        
        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
        }
        </style>
        <?php
    }

    protected function content_template() {
        ?>
        <div class="dunmedic-appointment-form-widget">
            <div class="appointment-form-container">
                <h3 class="appointment-form-title">{{{ settings.form_title }}}</h3>
                <# if ( settings.form_description ) { #>
                    <p class="form-description">{{{ settings.form_description }}}</p>
                <# } #>
                
                <form class="dunmedic-appointment-form">
                    <div class="form-row">
                        <# if ( settings.enable_specialty_field === 'yes' ) { #>
                        <div class="form-field">
                            <label>Medical Specialty</label>
                            <select>
                                <option>Select Specialty</option>
                                <option>Critical Care</option>
                                <option>Internal Medicine</option>
                                <option>Dental</option>
                                <option>Emergency</option>
                            </select>
                        </div>
                        <# } #>
                        
                        <# if ( settings.enable_doctor_field === 'yes' ) { #>
                        <div class="form-field">
                            <label>Select Doctor</label>
                            <select>
                                <option>Select Doctor</option>
                                <option>Dr. Morgan Smith</option>
                                <option>Dr. Roy Coleman</option>
                            </select>
                        </div>
                        <# } #>
                        
                        <div class="form-field">
                            <label>Appointment Date</label>
                            <input type="date">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-field">
                            <label>Full Name</label>
                            <input type="text" placeholder="Enter your name">
                        </div>
                        
                        <div class="form-field">
                            <label>Phone Number</label>
                            <input type="tel" placeholder="Enter your phone">
                        </div>
                        
                        <div class="form-field">
                            <label>Email Address</label>
                            <input type="email" placeholder="Enter your email">
                        </div>
                        
                        <div class="form-field">
                            <label>Preferred Time</label>
                            <input type="time">
                        </div>
                    </div>
                    
                    <div class="form-field">
                        <label>Additional Message</label>
                        <textarea rows="4" placeholder="Please describe your symptoms or reason for visit..."></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">
                        <i class="fas fa-calendar-check"></i>
                        Make Appointment
                    </button>
                </form>
            </div>
        </div>
        <?php
    }
}
?>