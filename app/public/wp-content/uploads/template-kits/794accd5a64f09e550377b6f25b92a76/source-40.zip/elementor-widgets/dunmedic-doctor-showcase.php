<?php
/**
 * Dunmedic Doctor Showcase Widget for Elementor
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Dunmedic_Doctor_Showcase_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dunmedic_doctor_showcase';
    }

    public function get_title() {
        return esc_html__('Dunmedic Doctor Showcase', 'dunmedic');
    }

    public function get_icon() {
        return 'eicon-person';
    }

    public function get_categories() {
        return ['dunmedic'];
    }

    public function get_keywords() {
        return ['dunmedic', 'doctor', 'medical', 'team', 'healthcare'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'doctors',
            [
                'label' => esc_html__('Doctors', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'doctor_name',
                        'label' => esc_html__('Doctor Name', 'dunmedic'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Dr. John Doe', 'dunmedic'),
                    ],
                    [
                        'name' => 'doctor_specialty',
                        'label' => esc_html__('Specialty', 'dunmedic'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('Cardiology', 'dunmedic'),
                    ],
                    [
                        'name' => 'doctor_image',
                        'label' => esc_html__('Doctor Image', 'dunmedic'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'default' => [
                            'url' => 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                        ],
                    ],
                    [
                        'name' => 'doctor_experience',
                        'label' => esc_html__('Years of Experience', 'dunmedic'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'default' => esc_html__('10 years', 'dunmedic'),
                    ],
                ],
                'default' => [
                    [
                        'doctor_name' => 'Dr. Morgan Smith',
                        'doctor_specialty' => 'Dermatology',
                        'doctor_image' => [
                            'url' => 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                        ],
                        'doctor_experience' => '12 years',
                    ],
                    [
                        'doctor_name' => 'Dr. Roy Coleman',
                        'doctor_specialty' => 'Cardiology',
                        'doctor_image' => [
                            'url' => 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                        ],
                        'doctor_experience' => '15 years',
                    ],
                ],
                'title_field' => '{{{ doctor_name }}}',
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => esc_html__('2 Columns', 'dunmedic'),
                    '3' => esc_html__('3 Columns', 'dunmedic'),
                    '4' => esc_html__('4 Columns', 'dunmedic'),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => esc_html__('Card Background', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dunmedic-doctor-card' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $doctors = $settings['doctors'];
        $columns = $settings['columns'];
        
        ?>
        <div class="dunmedic-doctor-showcase-widget">
            <div class="dunmedic-doctors-grid" data-columns="<?php echo esc_attr($columns); ?>">
                <?php foreach ($doctors as $doctor): ?>
                    <div class="dunmedic-doctor-card">
                        <div class="doctor-image">
                            <img src="<?php echo esc_url($doctor['doctor_image']['url']); ?>" alt="<?php echo esc_attr($doctor['doctor_name']); ?>">
                        </div>
                        <h3 class="doctor-name"><?php echo esc_html($doctor['doctor_name']); ?></h3>
                        <p class="doctor-specialty"><?php echo esc_html($doctor['doctor_specialty']); ?></p>
                        <?php if (!empty($doctor['doctor_experience'])): ?>
                            <p class="doctor-experience"><?php echo esc_html($doctor['doctor_experience']); ?> experience</p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <div class="dunmedic-doctor-showcase-widget">
            <div class="dunmedic-doctors-grid" data-columns="{{ settings.columns }}">
                <# _.each( settings.doctors, function( doctor ) { #>
                    <div class="dunmedic-doctor-card">
                        <div class="doctor-image">
                            <img src="{{ doctor.doctor_image.url }}" alt="{{ doctor.doctor_name }}">
                        </div>
                        <h3 class="doctor-name">{{ doctor.doctor_name }}</h3>
                        <p class="doctor-specialty">{{ doctor.doctor_specialty }}</p>
                        <# if ( doctor.doctor_experience ) { #>
                            <p class="doctor-experience">{{ doctor.doctor_experience }} experience</p>
                        <# } #>
                    </div>
                <# }); #>
            </div>
        </div>
        <?php
    }
}
?>