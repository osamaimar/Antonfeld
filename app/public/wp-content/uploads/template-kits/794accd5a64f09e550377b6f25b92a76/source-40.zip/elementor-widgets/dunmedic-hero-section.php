<?php
/**
 * Dunmedic Hero Section Widget for Elementor
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Dunmedic_Hero_Section_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dunmedic_hero_section';
    }

    public function get_title() {
        return esc_html__('Dunmedic Hero Section', 'dunmedic');
    }

    public function get_icon() {
        return 'eicon-header';
    }

    public function get_categories() {
        return ['dunmedic'];
    }

    public function get_keywords() {
        return ['dunmedic', 'hero', 'medical', 'healthcare', 'banner'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'hero_title',
            [
                'label' => esc_html__('Hero Title', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Better care for your health', 'dunmedic'),
                'placeholder' => esc_html__('Enter your title', 'dunmedic'),
            ]
        );

        $this->add_control(
            'hero_description',
            [
                'label' => esc_html__('Description', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('The health and well-being of our patients and their health care team will always be our priority, so we follow the best practices for cleanliness.', 'dunmedic'),
                'placeholder' => esc_html__('Enter your description', 'dunmedic'),
            ]
        );

        $this->add_control(
            'hero_image',
            [
                'label' => esc_html__('Hero Image', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=600&h=800&fit=crop',
                ],
            ]
        );

        $this->add_control(
            'show_buttons',
            [
                'label' => esc_html__('Show Action Buttons', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Show', 'dunmedic'),
                'label_off' => esc_html__('Hide', 'dunmedic'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Title Color', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#1e293b',
                'selectors' => [
                    '{{WRAPPER}} .hero-title' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => esc_html__('Description Color', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#64748b',
                'selectors' => [
                    '{{WRAPPER}} .hero-description' => 'color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $hero_image = $settings['hero_image']['url'];
        $show_buttons = $settings['show_buttons'] === 'yes';
        
        ?>
        <div class="dunmedic-hero-section-widget">
            <div class="hero-container">
                <div class="hero-content">
                    <h1 class="hero-title"><?php echo esc_html($settings['hero_title']); ?></h1>
                    <p class="hero-description"><?php echo esc_html($settings['hero_description']); ?></p>
                    
                    <?php if ($show_buttons): ?>
                    <div class="hero-buttons">
                        <a href="#services" class="dunmedic-btn dunmedic-btn-primary">
                            View our services
                        </a>
                        <a href="tel:+1234567890" class="dunmedic-btn dunmedic-btn-emergency">
                            <i class="fas fa-phone-alt"></i>
                            Emergency
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="hero-visual">
                    <img src="<?php echo esc_url($hero_image); ?>" alt="Medical Professional" class="hero-image">
                </div>
            </div>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <div class="dunmedic-hero-section-widget">
            <div class="hero-container">
                <div class="hero-content">
                    <h1 class="hero-title">{{{ settings.hero_title }}}</h1>
                    <p class="hero-description">{{{ settings.hero_description }}}</p>
                    
                    <# if ( settings.show_buttons === 'yes' ) { #>
                    <div class="hero-buttons">
                        <a href="#services" class="dunmedic-btn dunmedic-btn-primary">
                            View our services
                        </a>
                        <a href="tel:+1234567890" class="dunmedic-btn dunmedic-btn-emergency">
                            <i class="fas fa-phone-alt"></i>
                            Emergency
                        </a>
                    </div>
                    <# } #>
                </div>
                
                <div class="hero-visual">
                    <img src="{{{ settings.hero_image.url }}}" alt="Medical Professional" class="hero-image">
                </div>
            </div>
        </div>
        <?php
    }
}
?>