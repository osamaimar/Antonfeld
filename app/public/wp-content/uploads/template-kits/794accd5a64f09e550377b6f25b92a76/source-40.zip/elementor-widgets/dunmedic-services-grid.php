<?php
/**
 * Dunmedic Services Grid Widget for Elementor
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Dunmedic_Services_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'dunmedic_services_grid';
    }

    public function get_title() {
        return esc_html__('Dunmedic Services Grid', 'dunmedic');
    }

    public function get_icon() {
        return 'eicon-medical';
    }

    public function get_categories() {
        return ['dunmedic'];
    }

    public function get_keywords() {
        return ['dunmedic', 'medical', 'services', 'healthcare', 'grid'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'service_category',
            [
                'label' => esc_html__('Service Category', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('All Services', 'dunmedic'),
                    'critical-care' => esc_html__('Critical Care', 'dunmedic'),
                    'internal-medicine' => esc_html__('Internal Medicine', 'dunmedic'),
                    'dental' => esc_html__('Dental', 'dunmedic'),
                    'emergency' => esc_html__('Emergency', 'dunmedic'),
                    'dermatology' => esc_html__('Dermatology', 'dunmedic'),
                    'family-medicine' => esc_html__('Family Medicine', 'dunmedic'),
                    'surgery' => esc_html__('Surgery', 'dunmedic'),
                    'cardiology' => esc_html__('Cardiology', 'dunmedic'),
                ],
            ]
        );

        $this->add_control(
            'services_limit',
            [
                'label' => esc_html__('Services Limit', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 4,
                'min' => 1,
                'max' => 12,
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => esc_html__('2 Columns', 'dunmedic'),
                    '3' => esc_html__('3 Columns', 'dunmedic'),
                    '4' => esc_html__('4 Columns', 'dunmedic'),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'dunmedic'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => esc_html__('Card Background', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .dunmedic-service-item' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => esc_html__('Border Radius', 'dunmedic'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '12',
                    'left' => '12',
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .dunmedic-service-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_shadow',
                'label' => esc_html__('Box Shadow', 'dunmedic'),
                'selector' => '{{WRAPPER}} .dunmedic-service-item',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        echo do_shortcode('[dunmedic_services category="' . esc_attr($settings['service_category']) . '" limit="' . esc_attr($settings['services_limit']) . '" columns="' . esc_attr($settings['columns']) . '"]');
    }

    protected function content_template() {
        ?>
        <div class="dunmedic-services-grid" data-columns="{{ settings.columns }}">
            <div class="dunmedic-service-item">
                <div class="service-icon">
                    <i class="fas fa-heartbeat"></i>
                </div>
                <h3 class="service-title">Critical Care</h3>
                <p class="service-description">Advanced critical care and intensive monitoring for serious medical conditions.</p>
            </div>
            <div class="dunmedic-service-item">
                <div class="service-icon">
                    <i class="fas fa-stethoscope"></i>
                </div>
                <h3 class="service-title">Internal Medicine</h3>
                <p class="service-description">Comprehensive internal medicine services for adult patients.</p>
            </div>
        </div>
        <?php
    }
}
?>