# Dunmedic Medical and Healthcare Template

A modern, responsive medical and healthcare template designed for Elementor page builder.

## Features

- **Responsive Design**: Optimized for all devices and screen sizes
- **Custom Elementor Widgets**: Specialized widgets for medical services, doctor profiles, and appointment booking
- **Interactive Elements**: Animated medical icons and professional doctor showcases
- **Modern Medical Aesthetics**: Clean design with professional medical color scheme
- **Performance Optimized**: Lightweight code with efficient loading

## Installation Instructions

### Method 1: Import Template JSON

1. **Download the template files** to your computer
2. **Login to your WordPress admin panel**
3. **Navigate to** `Templates > Saved Templates` in Elementor
4. **Click "Import Templates"**
5. **Upload the `template.json` file**
6. **Click "Import Now"**

### Method 2: Manual Setup

1. **Upload theme files** to your WordPress theme directory:
   ```
   /wp-content/themes/your-theme/
   ├── functions.php (merge with existing)
   ├── style.css (merge with existing)
   ├── elementor-widgets/
   │   ├── dunmedic-services-grid.php
   │   ├── dunmedic-hero-section.php
   │   ├── dunmedic-doctor-showcase.php
   │   └── dunmedic-appointment-form.php
   └── assets/
       ├── css/
       │   └── dunmedic-main.css
       └── js/
           └── dunmedic-elementor.js
   ```

2. **Add the functions.php code** to your theme's functions.php file
3. **Activate the template** in Elementor

## Custom Widgets

### 1. Dunmedic Services Grid
- **Purpose**: Display medical services in a responsive grid layout
- **Settings**: Service category filter, service limit, column count
- **Features**: Hover effects, medical icons, responsive design

### 2. Dunmedic Hero Section
- **Purpose**: Professional hero section with medical imagery
- **Settings**: Background options, call-to-action buttons
- **Features**: Gradient backgrounds, animated elements, appointment booking

### 3. Dunmedic Doctor Showcase
- **Purpose**: Display doctor profiles with specialties
- **Settings**: Doctor selection, layout options
- **Features**: Professional photos, specialty information, contact details

### 4. Dunmedic Appointment Form
- **Purpose**: Interactive appointment booking form
- **Settings**: Form fields, doctor selection, time slots
- **Features**: Date picker, specialty selection, form validation

## Customization

### Colors
The template uses CSS custom properties for easy color customization:

```css
:root {
    --dunmedic-primary: #2563eb;
    --dunmedic-secondary: #f8fafc;
    --dunmedic-accent: #10b981;
    --dunmedic-text-primary: #1e293b;
    /* ... more variables */
}
```

### Typography
The template uses the Poppins font family. You can change this in the CSS variables:

```css
:root {
    --dunmedic-font-family: 'Poppins', sans-serif;
}
```

### Medical Services

The template supports these medical specialties:
- Critical Care
- Internal Medicine
- Dental
- Emergency
- Dermatology
- Family Medicine
- Surgery
- Cardiology

## Doctor Setup

### Creating Doctor Profiles

1. **Navigate to** `Doctors` in your WordPress admin
2. **Click "Add New"**
3. **Fill in doctor details**:
   - Name
   - Specialty
   - Bio
   - Featured Image
   - Contact Information
   - Qualifications

## Shortcodes

### Services Grid
```php
[dunmedic_services category="emergency" limit="4" columns="4"]
```

### Doctor Profiles
```php
[dunmedic_doctors specialty="cardiology"]
```

## Browser Support

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+

## Performance Tips

1. **Optimize Images**: Use WebP format when possible
2. **Lazy Loading**: Images are lazy-loaded by default
3. **Minify Assets**: Minify CSS and JS files for production
4. **Caching**: Use a caching plugin for better performance

## Troubleshooting

### Widgets Not Appearing
- Ensure Elementor is active and updated
- Check that all widget files are uploaded correctly
- Verify functions.php code is added properly

### Animations Not Working
- Check that JavaScript files are loading correctly
- Ensure jQuery is available
- Verify no JavaScript errors in browser console

### Styling Issues
- Clear any caching plugins
- Check for CSS conflicts with other plugins
- Ensure all CSS files are enqueued properly

## Support

For support and customization requests, please refer to the documentation or contact the template author.

## Changelog

### Version 1.0.0
- Initial medical template release
- Custom medical Elementor widgets
- Responsive design
- Medical animations
- Doctor and appointment management system

## License

This template is provided as-is for use with Elementor page builder. Please ensure you have proper licensing for any third-party assets used.