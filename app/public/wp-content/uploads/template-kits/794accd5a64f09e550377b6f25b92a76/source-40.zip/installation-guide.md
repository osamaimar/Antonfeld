# Dunmedic Medical Template Kit - Installation Guide

## For Envato Template Kit Import Plugin

### Step 1: Download and Prepare
1. Download all files from this template kit
2. Create a new folder called `dunmedic-medical-kit`
3. Copy all files into this folder

### Step 2: Create Template Kit ZIP
1. Select all files in the `dunmedic-medical-kit` folder:
   - `kit-info.json`
   - `manifest.json`
   - `metadata.json`
   - `plugin-requirements.json`
   - `templates/` folder
   - `theme-files/` folder
2. Create a ZIP file containing all these files
3. Name the ZIP file `dunmedic-medical-kit.zip`

### Step 3: Install Template Kit Import Plugin
1. In your WordPress admin, go to **Plugins > Add New**
2. Search for "Template Kit Import"
3. Install and activate the plugin by Envato

### Step 4: Import Template Kit
1. Go to **Template Kits > Import Kit**
2. Click "Upload Template Kit"
3. Select your `dunmedic-medical-kit.zip` file
4. Click "Import Kit"

### Step 5: Use Templates
1. Edit any page with Elementor
2. Click the folder icon to open templates
3. Go to "My Templates" tab
4. Find "Dunmedic Medical Homepage"
5. Click "Insert" to add the template

## Alternative Method: Manual Import

If you prefer to import individual templates:

1. Go to **Elementor > My Templates**
2. Click "Import Templates"
3. Upload the `templates/homepage.json` file
4. The template will be available in your template library

## Theme Integration

To use the custom widgets and styling:

1. Copy the contents of `theme-files/functions.php` to your active theme's `functions.php` file
2. Upload the `theme-files/assets/` folder to your theme directory
3. Upload the `theme-files/elementor-widgets/` folder to your theme directory
4. The custom Dunmedic widgets will appear in Elementor under the "Dunmedic Medical" category

## Required Plugins

- **Elementor** (free version) - Required
- **Elementor Pro** (optional) - For advanced form features

## Troubleshooting

### Template Kit Won't Import
- Ensure the ZIP file contains all required files
- Check that the Template Kit Import plugin is active
- Verify your WordPress and Elementor versions meet requirements

### Custom Widgets Not Showing
- Ensure you've added the functions.php code to your theme
- Check that all widget files are uploaded to the correct directory
- Verify there are no PHP errors in your error log

### Styling Issues
- Make sure the CSS files are properly enqueued
- Check for conflicts with other plugins or themes
- Clear any caching plugins after installation

## Support

For additional support or customization requests, please refer to the documentation or contact the template author.