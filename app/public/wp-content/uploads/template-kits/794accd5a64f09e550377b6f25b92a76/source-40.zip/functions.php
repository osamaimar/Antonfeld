<?php
/**
 * Dunmedic Medical and Healthcare Template Functions
 * 
 * This file contains custom functions and hooks for the Dunmedic medical template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue Dunmedic styles and scripts
 */
function dunmedic_enqueue_assets() {
    // Enqueue Google Fonts
    wp_enqueue_style(
        'dunmedic-google-fonts',
        'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap',
        array(),
        '1.0.0'
    );
    
    // Enqueue main stylesheet
    wp_enqueue_style(
        'dunmedic-main-style',
        get_template_directory_uri() . '/assets/css/dunmedic-main.css',
        array(),
        '1.0.0'
    );
    
    // Enqueue components stylesheet
    wp_enqueue_style(
        'dunmedic-components-style',
        get_template_directory_uri() . '/assets/css/dunmedic-components.css',
        array('dunmedic-main-style'),
        '1.0.0'
    );
    
    // Enqueue animations stylesheet
    wp_enqueue_style(
        'dunmedic-animations-style',
        get_template_directory_uri() . '/assets/css/dunmedic-animations.css',
        array('dunmedic-main-style'),
        '1.0.0'
    );
    
    // Enqueue JavaScript files
    wp_enqueue_script(
        'dunmedic-main',
        get_template_directory_uri() . '/assets/js/dunmedic-main.js',
        array('jquery'),
        '1.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'dunmedic_enqueue_assets');

/**
 * Add custom CSS variables to Elementor
 */
function dunmedic_add_elementor_css_variables() {
    ?>
    <style>
        :root {
            --dunmedic-primary: #2563eb;
            --dunmedic-primary-hover: #1d4ed8;
            --dunmedic-secondary: #f8fafc;
            --dunmedic-accent: #10b981;
            --dunmedic-text-primary: #1e293b;
            --dunmedic-text-secondary: #64748b;
            --dunmedic-text-light: #ffffff;
            --dunmedic-border: #e2e8f0;
            --dunmedic-shadow-light: 0 2px 10px rgba(0, 0, 0, 0.1);
            --dunmedic-shadow-medium: 0 4px 20px rgba(0, 0, 0, 0.15);
            --dunmedic-shadow-heavy: 0 8px 30px rgba(0, 0, 0, 0.2);
            --dunmedic-spacing-xs: 0.5rem;
            --dunmedic-spacing-sm: 1rem;
            --dunmedic-spacing-md: 1.5rem;
            --dunmedic-spacing-lg: 2rem;
            --dunmedic-spacing-xl: 3rem;
            --dunmedic-spacing-xxl: 4rem;
            --dunmedic-font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            --dunmedic-radius-sm: 0.375rem;
            --dunmedic-radius-md: 0.5rem;
            --dunmedic-radius-lg: 0.75rem;
            --dunmedic-radius-xl: 1rem;
            --dunmedic-transition-fast: 0.15s ease;
            --dunmedic-transition-normal: 0.3s ease;
            --dunmedic-transition-slow: 0.5s ease;
        }
    </style>
    <?php
}
add_action('wp_head', 'dunmedic_add_elementor_css_variables');

/**
 * Register custom Elementor widgets
 */
function dunmedic_register_elementor_widgets() {
    // Check if Elementor is active
    if (!did_action('elementor/loaded')) {
        return;
    }
    
    // Include custom widget files
    require_once get_template_directory() . '/elementor-widgets/dunmedic-services-grid.php';
    require_once get_template_directory() . '/elementor-widgets/dunmedic-hero-section.php';
    require_once get_template_directory() . '/elementor-widgets/dunmedic-doctor-showcase.php';
    require_once get_template_directory() . '/elementor-widgets/dunmedic-appointment-form.php';
    
    // Register widgets
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Dunmedic_Services_Grid_Widget());
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Dunmedic_Hero_Section_Widget());
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Dunmedic_Doctor_Showcase_Widget());
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type(new \Dunmedic_Appointment_Form_Widget());
}
add_action('elementor/widgets/widgets_registered', 'dunmedic_register_elementor_widgets');

/**
 * Add Dunmedic category to Elementor panel
 */
function dunmedic_add_elementor_widget_categories($elements_manager) {
    $elements_manager->add_category(
        'dunmedic',
        [
            'title' => esc_html__('Dunmedic Medical', 'dunmedic'),
            'icon' => 'fa fa-heartbeat',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'dunmedic_add_elementor_widget_categories');

/**
 * Custom post type for doctors
 */
function dunmedic_register_doctor_post_type() {
    $args = array(
        'public' => true,
        'label' => 'Doctors',
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon' => 'dashicons-admin-users',
        'has_archive' => true,
        'rewrite' => array('slug' => 'doctors'),
    );
    register_post_type('dunmedic_doctor', $args);
}
add_action('init', 'dunmedic_register_doctor_post_type');

/**
 * Custom post type for services
 */
function dunmedic_register_service_post_type() {
    $args = array(
        'public' => true,
        'label' => 'Medical Services',
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
        'menu_icon' => 'dashicons-heart',
        'has_archive' => true,
        'rewrite' => array('slug' => 'services'),
    );
    register_post_type('dunmedic_service', $args);
}
add_action('init', 'dunmedic_register_service_post_type');

/**
 * Add custom meta fields for doctors
 */
function dunmedic_add_doctor_meta_boxes() {
    add_meta_box(
        'dunmedic_doctor_details',
        'Doctor Details',
        'dunmedic_doctor_details_callback',
        'dunmedic_doctor',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'dunmedic_add_doctor_meta_boxes');

function dunmedic_doctor_details_callback($post) {
    wp_nonce_field('dunmedic_save_doctor_details', 'dunmedic_doctor_nonce');
    
    $specialty = get_post_meta($post->ID, '_dunmedic_specialty', true);
    $phone = get_post_meta($post->ID, '_dunmedic_phone', true);
    $email = get_post_meta($post->ID, '_dunmedic_email', true);
    $experience = get_post_meta($post->ID, '_dunmedic_experience', true);
    $qualifications = get_post_meta($post->ID, '_dunmedic_qualifications', true);
    
    ?>
    <table class="form-table">
        <tr>
            <th><label for="dunmedic_specialty">Medical Specialty</label></th>
            <td>
                <select id="dunmedic_specialty" name="dunmedic_specialty">
                    <option value="">Select Specialty</option>
                    <option value="critical-care" <?php selected($specialty, 'critical-care'); ?>>Critical Care</option>
                    <option value="internal-medicine" <?php selected($specialty, 'internal-medicine'); ?>>Internal Medicine</option>
                    <option value="dental" <?php selected($specialty, 'dental'); ?>>Dental</option>
                    <option value="emergency" <?php selected($specialty, 'emergency'); ?>>Emergency</option>
                    <option value="dermatology" <?php selected($specialty, 'dermatology'); ?>>Dermatology</option>
                    <option value="family-medicine" <?php selected($specialty, 'family-medicine'); ?>>Family Medicine</option>
                    <option value="surgery" <?php selected($specialty, 'surgery'); ?>>Surgery</option>
                    <option value="cardiology" <?php selected($specialty, 'cardiology'); ?>>Cardiology</option>
                </select>
            </td>
        </tr>
        <tr>
            <th><label for="dunmedic_phone">Phone Number</label></th>
            <td><input type="text" id="dunmedic_phone" name="dunmedic_phone" value="<?php echo esc_attr($phone); ?>" /></td>
        </tr>
        <tr>
            <th><label for="dunmedic_email">Email Address</label></th>
            <td><input type="email" id="dunmedic_email" name="dunmedic_email" value="<?php echo esc_attr($email); ?>" /></td>
        </tr>
        <tr>
            <th><label for="dunmedic_experience">Years of Experience</label></th>
            <td><input type="number" id="dunmedic_experience" name="dunmedic_experience" value="<?php echo esc_attr($experience); ?>" /></td>
        </tr>
        <tr>
            <th><label for="dunmedic_qualifications">Qualifications</label></th>
            <td><textarea id="dunmedic_qualifications" name="dunmedic_qualifications" rows="4"><?php echo esc_textarea($qualifications); ?></textarea></td>
        </tr>
    </table>
    <?php
}

/**
 * Save doctor meta data
 */
function dunmedic_save_doctor_details($post_id) {
    if (!isset($_POST['dunmedic_doctor_nonce']) || !wp_verify_nonce($_POST['dunmedic_doctor_nonce'], 'dunmedic_save_doctor_details')) {
        return;
    }
    
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    $fields = array('specialty', 'phone', 'email', 'experience', 'qualifications');
    
    foreach ($fields as $field) {
        if (isset($_POST['dunmedic_' . $field])) {
            update_post_meta($post_id, '_dunmedic_' . $field, sanitize_text_field($_POST['dunmedic_' . $field]));
        }
    }
}
add_action('save_post', 'dunmedic_save_doctor_details');

/**
 * Helper function to get doctor data
 */
function dunmedic_get_doctor_data($post_id) {
    return array(
        'id' => $post_id,
        'name' => get_the_title($post_id),
        'specialty' => get_post_meta($post_id, '_dunmedic_specialty', true),
        'phone' => get_post_meta($post_id, '_dunmedic_phone', true),
        'email' => get_post_meta($post_id, '_dunmedic_email', true),
        'experience' => get_post_meta($post_id, '_dunmedic_experience', true),
        'qualifications' => get_post_meta($post_id, '_dunmedic_qualifications', true),
        'image' => get_the_post_thumbnail_url($post_id, 'medium'),
        'permalink' => get_permalink($post_id),
    );
}

/**
 * AJAX handler for appointment booking
 */
function dunmedic_ajax_book_appointment() {
    check_ajax_referer('dunmedic_appointment_nonce', 'nonce');
    
    $appointment_data = array(
        'doctor_id' => sanitize_text_field($_POST['doctor_id']),
        'patient_name' => sanitize_text_field($_POST['patient_name']),
        'patient_email' => sanitize_email($_POST['patient_email']),
        'patient_phone' => sanitize_text_field($_POST['patient_phone']),
        'appointment_date' => sanitize_text_field($_POST['appointment_date']),
        'appointment_time' => sanitize_text_field($_POST['appointment_time']),
        'specialty' => sanitize_text_field($_POST['specialty']),
        'message' => sanitize_textarea_field($_POST['message']),
    );
    
    // Here you would typically save to database or send email
    // For now, we'll just return success
    wp_send_json_success(array(
        'message' => 'Appointment request submitted successfully. We will contact you soon.',
        'data' => $appointment_data
    ));
}
add_action('wp_ajax_dunmedic_book_appointment', 'dunmedic_ajax_book_appointment');
add_action('wp_ajax_nopriv_dunmedic_book_appointment', 'dunmedic_ajax_book_appointment');

/**
 * Add theme support for Elementor
 */
function dunmedic_theme_support() {
    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
}
add_action('after_setup_theme', 'dunmedic_theme_support');

/**
 * Customize Elementor settings for medical theme
 */
function dunmedic_elementor_settings() {
    // Update Elementor color scheme
    update_option('elementor_scheme_color', array(
        '1' => '#2563eb', // Primary Blue
        '2' => '#f8fafc', // Light Gray
        '3' => '#1e293b', // Dark Text
        '4' => '#10b981', // Accent Green
    ));
    
    // Update Elementor typography scheme
    update_option('elementor_scheme_typography', array(
        '1' => array(
            'font_family' => 'Poppins',
            'font_weight' => '600',
        ),
        '2' => array(
            'font_family' => 'Poppins',
            'font_weight' => '400',
        ),
        '3' => array(
            'font_family' => 'Poppins',
            'font_weight' => '500',
        ),
        '4' => array(
            'font_family' => 'Poppins',
            'font_weight' => '700',
        ),
    ));
}
add_action('init', 'dunmedic_elementor_settings');

/**
 * Custom shortcodes for Dunmedic functionality
 */

// Services grid shortcode
function dunmedic_services_grid_shortcode($atts) {
    $atts = shortcode_atts(array(
        'category' => '',
        'limit' => 4,
        'columns' => 4,
    ), $atts);
    
    $services = array(
        array(
            'title' => 'Critical Care',
            'icon' => 'fas fa-heartbeat',
            'description' => 'Advanced critical care and intensive monitoring for serious medical conditions.'
        ),
        array(
            'title' => 'Internal Medicine',
            'icon' => 'fas fa-stethoscope',
            'description' => 'Comprehensive internal medicine services for adult patients.'
        ),
        array(
            'title' => 'Dental',
            'icon' => 'fas fa-tooth',
            'description' => 'Complete dental care including preventive and restorative treatments.'
        ),
        array(
            'title' => 'Emergency',
            'icon' => 'fas fa-ambulance',
            'description' => '24/7 emergency medical services for urgent health situations.'
        ),
    );
    
    ob_start();
    ?>
    <div class="dunmedic-services-grid" data-columns="<?php echo esc_attr($atts['columns']); ?>">
        <?php foreach (array_slice($services, 0, $atts['limit']) as $service): ?>
            <div class="dunmedic-service-item">
                <div class="service-icon">
                    <i class="<?php echo esc_attr($service['icon']); ?>"></i>
                </div>
                <h3 class="service-title"><?php echo esc_html($service['title']); ?></h3>
                <p class="service-description"><?php echo esc_html($service['description']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dunmedic_services', 'dunmedic_services_grid_shortcode');

// Doctor showcase shortcode
function dunmedic_doctor_showcase_shortcode($atts) {
    $doctors = array(
        array(
            'name' => 'Dr. Morgan Smith',
            'specialty' => 'Dermatology',
            'image' => 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'
        ),
        array(
            'name' => 'Dr. Roy Coleman',
            'specialty' => 'Cardiology',
            'image' => 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'
        ),
        array(
            'name' => 'Dr. Lyla Miss',
            'specialty' => 'Emergency Medicine',
            'image' => 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'
        ),
        array(
            'name' => 'Dr. Lake Yinus',
            'specialty' => 'Internal Medicine',
            'image' => 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop'
        ),
    );
    
    ob_start();
    ?>
    <div class="dunmedic-doctors-grid" data-columns="4">
        <?php foreach ($doctors as $doctor): ?>
            <div class="dunmedic-doctor-card">
                <div class="doctor-image">
                    <img src="<?php echo esc_url($doctor['image']); ?>" alt="<?php echo esc_attr($doctor['name']); ?>">
                </div>
                <h3 class="doctor-name"><?php echo esc_html($doctor['name']); ?></h3>
                <p class="doctor-specialty"><?php echo esc_html($doctor['specialty']); ?></p>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('dunmedic_doctors', 'dunmedic_doctor_showcase_shortcode');

/**
 * Localize script for AJAX
 */
function dunmedic_localize_scripts() {
    wp_localize_script('dunmedic-main', 'dunmedic_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('dunmedic_appointment_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'dunmedic_localize_scripts');
?>