/**
 * Dunmedic Medical Template Main JavaScript
 */

(function($) {
    'use strict';

    // Medical data
    const medicalData = {
        services: [
            {
                id: 'critical-care',
                title: 'Critical Care',
                icon: 'fas fa-heartbeat',
                description: 'Advanced critical care and intensive monitoring for serious medical conditions.',
                color: '#dc2626'
            },
            {
                id: 'internal-medicine',
                title: 'Internal Medicine',
                icon: 'fas fa-stethoscope',
                description: 'Comprehensive internal medicine services for adult patients.',
                color: '#2563eb'
            },
            {
                id: 'dental',
                title: 'Dental',
                icon: 'fas fa-tooth',
                description: 'Complete dental care including preventive and restorative treatments.',
                color: '#10b981'
            },
            {
                id: 'emergency',
                title: 'Emergency',
                icon: 'fas fa-ambulance',
                description: '24/7 emergency medical services for urgent health situations.',
                color: '#f59e0b'
            }
        ],
        doctors: [
            {
                id: 'dr-morgan-smith',
                name: 'Dr. Morgan Smith',
                specialty: 'Dermatology',
                image: 'https://images.pexels.com/photos/5327585/pexels-photo-5327585.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                experience: '12 years',
                phone: '+1 (555) 123-4567',
                email: 'morgan.smith@dunmedic.com'
            },
            {
                id: 'dr-roy-coleman',
                name: 'Dr. Roy Coleman',
                specialty: 'Cardiology',
                image: 'https://images.pexels.com/photos/6749778/pexels-photo-6749778.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                experience: '15 years',
                phone: '+1 (555) 123-4568',
                email: 'roy.coleman@dunmedic.com'
            },
            {
                id: 'dr-lyla-miss',
                name: 'Dr. Lyla Miss',
                specialty: 'Emergency Medicine',
                image: 'https://images.pexels.com/photos/5327921/pexels-photo-5327921.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                experience: '10 years',
                phone: '+1 (555) 123-4569',
                email: 'lyla.miss@dunmedic.com'
            },
            {
                id: 'dr-lake-yinus',
                name: 'Dr. Lake Yinus',
                specialty: 'Internal Medicine',
                image: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
                experience: '18 years',
                phone: '+1 (555) 123-4570',
                email: 'lake.yinus@dunmedic.com'
            }
        ]
    };

    // Initialize medical template
    class DunmedicTemplate {
        constructor() {
            this.init();
        }

        init() {
            this.initAnimations();
            this.initAppointmentForm();
            this.initCounters();
            this.initProgressBars();
            this.updateTime();
            this.initScrollEffects();
        }

        // Initialize scroll-based animations
        initAnimations() {
            const observerOptions = {
                threshold: 0.1,
                rootMargin: '0px 0px -50px 0px'
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('animated');
                    }
                });
            }, observerOptions);

            // Observe elements with animation classes
            document.querySelectorAll('.fade-in-up, .scale-in, .dunmedic-fade-up, .dunmedic-scale-in').forEach(el => {
                observer.observe(el);
            });
        }

        // Initialize appointment form functionality
        initAppointmentForm() {
            const forms = document.querySelectorAll('.elementor-form');
            
            forms.forEach(form => {
                form.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.handleAppointmentSubmission(form);
                });
            });
        }

        // Handle appointment form submission
        handleAppointmentSubmission(form) {
            const formData = new FormData(form);
            const appointmentData = {};
            
            for (let [key, value] of formData.entries()) {
                appointmentData[key] = value;
            }

            // Show loading state
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Booking...';
            submitBtn.disabled = true;

            // Simulate API call
            setTimeout(() => {
                // Show success message
                this.showNotification('Appointment booked successfully! We will contact you soon.', 'success');
                
                // Reset form
                form.reset();
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        }

        // Initialize counter animations
        initCounters() {
            const counters = document.querySelectorAll('.elementor-counter-number');
            
            const counterObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.animateCounter(entry.target);
                        counterObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });

            counters.forEach(counter => {
                counterObserver.observe(counter);
            });
        }

        // Animate counter numbers
        animateCounter(element) {
            const target = parseInt(element.getAttribute('data-to-value') || element.textContent);
            const duration = parseInt(element.getAttribute('data-duration')) || 2000;
            const start = parseInt(element.getAttribute('data-from-value')) || 0;
            const increment = (target - start) / (duration / 16);
            let current = start;

            const timer = setInterval(() => {
                current += increment;
                if (current >= target) {
                    current = target;
                    clearInterval(timer);
                }
                element.textContent = Math.floor(current).toLocaleString();
            }, 16);
        }

        // Initialize progress bar animations
        initProgressBars() {
            const progressBars = document.querySelectorAll('.elementor-progress-bar');
            
            const progressObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        this.animateProgressBar(entry.target);
                        progressObserver.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });

            progressBars.forEach(bar => {
                progressObserver.observe(bar);
            });
        }

        // Animate progress bars
        animateProgressBar(element) {
            const percentage = element.getAttribute('data-max');
            const progressFill = element.querySelector('.elementor-progress-bar');
            
            if (progressFill) {
                setTimeout(() => {
                    progressFill.style.width = percentage + '%';
                }, 200);
            }
        }

        // Update time display
        updateTime() {
            const timeElements = document.querySelectorAll('#time, .phone-status-time');
            
            const updateTimeDisplay = () => {
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true
                });
                
                timeElements.forEach(element => {
                    if (element) {
                        element.textContent = timeString;
                    }
                });
            };

            updateTimeDisplay();
            setInterval(updateTimeDisplay, 60000); // Update every minute
        }

        // Initialize scroll effects
        initScrollEffects() {
            let ticking = false;

            const updateScrollEffects = () => {
                const scrolled = window.pageYOffset;
                const parallaxElements = document.querySelectorAll('[data-motion-fx-mouse]');
                
                parallaxElements.forEach(element => {
                    const speed = 0.5;
                    const yPos = -(scrolled * speed);
                    element.style.transform = `translateY(${yPos}px)`;
                });

                ticking = false;
            };

            const requestScrollUpdate = () => {
                if (!ticking) {
                    requestAnimationFrame(updateScrollEffects);
                    ticking = true;
                }
            };

            window.addEventListener('scroll', requestScrollUpdate);
        }

        // Show notification
        showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `medical-notification medical-notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                    <span>${message}</span>
                </div>
                <button class="notification-close">&times;</button>
            `;

            // Add styles
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : '#2563eb'};
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 0.5rem;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
                z-index: 10000;
                display: flex;
                align-items: center;
                gap: 1rem;
                max-width: 400px;
                animation: slideInRight 0.3s ease-out;
            `;

            document.body.appendChild(notification);

            // Auto remove after 5 seconds
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease-out';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 5000);

            // Close button functionality
            notification.querySelector('.notification-close').addEventListener('click', () => {
                notification.style.animation = 'slideOutRight 0.3s ease-out';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            });
        }

        // Get medical service data
        getServiceData(serviceId) {
            return medicalData.services.find(service => service.id === serviceId);
        }

        // Get doctor data
        getDoctorData(doctorId) {
            return medicalData.doctors.find(doctor => doctor.id === doctorId);
        }
    }

    // Initialize when document is ready
    $(document).ready(function() {
        window.dunmedicTemplate = new DunmedicTemplate();
        
        // Add CSS animations
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOutRight {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.5rem;
                flex: 1;
            }
            
            .notification-close {
                background: none;
                border: none;
                color: inherit;
                font-size: 1.2rem;
                cursor: pointer;
                padding: 0;
                width: 20px;
                height: 20px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
        `;
        document.head.appendChild(style);
    });

    // Expose medical data globally for widgets
    window.dunmedicData = medicalData;

})(jQuery);